# Digital-Image-watermarking
Java project for digital image watermarking in frequency domain using DCT-DWT-SVD theory.
JAMA library has been used for huge matrix computation.
